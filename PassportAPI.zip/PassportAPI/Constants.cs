﻿namespace PassportAPI
{
    public static class Constants
    {
        public const string AlbumStorage = "AlbumStorage";
        public const string PhotoStorage = "PhotoStorage";
    }
}
