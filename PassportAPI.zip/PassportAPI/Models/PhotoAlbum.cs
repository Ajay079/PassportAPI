﻿namespace PassportAPI.Models
{
    public class PhotoAlbum
    {
        public Album Album { get; set; }
        public Photo Photo { get; set; }
    }
}
